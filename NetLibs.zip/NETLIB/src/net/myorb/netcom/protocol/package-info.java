/**
 * the protocol implementations for net communications
 * @author Michael Druckman
 */
package net.myorb.netcom.protocol;