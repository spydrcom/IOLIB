/**
 * the net communications TCP socket layer implementations
 * @author Michael Druckman
 */
package net.myorb.netcom;