
package net.myorb.netcom.testing;

import net.myorb.netcom.*;

/**
 * test class for Raw Text RPC service
 */
public class TcpServer
{

	public static void main (String[] s) throws Exception
	{
		System.out.println ("test starts");
		postTo (8081); System.out.println ("server running");
	}

	public static void postTo (int port)
	{
		ServerConventions.provideService ("RAW", port, new Processor (), "\f");
	}

	public static void simpleTest () throws Exception
	{
		ServerTcpIO.Connection c;
		ServerTcpIO server = new ServerTcpIO (8081);
		
		while (true)
		{
			c = server.accept ();

			String content = c.read ();
			System.out.println (content);
			
			c.write ("content received");
			c.write (content);
			c.write ("*EOT*");

			c.close ();
		}
	}

}

class Processor implements ServerConventions.RawTextProcessor
{

	/* (non-Javadoc)
	 * @see net.myorb.data.abstractions.ServerConventions.RawTextProcessor#process(java.lang.String)
	 */
	public String process(String request) {
		System.out.println (request);
		return "OK, size=" + request.length();
	}
	
}

