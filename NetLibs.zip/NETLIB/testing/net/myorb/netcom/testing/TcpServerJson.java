
package net.myorb.netcom.testing;

import net.myorb.netcom.*;

import net.myorb.data.notations.json.JsonLowLevel.JsonValue;
import net.myorb.data.notations.json.JsonPrettyPrinter;

/**
 * test class for JSON RPC service
 */
public class TcpServerJson
{

	public static void main (String[] s) throws Exception
	{
		System.out.println ("test starts");
		postTo (8081); System.out.println ("server running");
	}

	public static void postTo (int port)
	{
		ServerConventions.provideService ("JSON", port, new JsonProcessor (), "\f");
	}

}

class JsonProcessor implements ServerConventions.JsonProcessor
{

	/* (non-Javadoc)
	 * @see net.myorb.data.abstractions.ServerConventions.JsonProcessor#process(net.myorb.data.notations.json.JsonLowLevel.JsonValue)
	 */
	public String process (JsonValue value)
	{
		try { JsonPrettyPrinter.sendTo (value, System.out); } catch (Exception e) {}
		return "OK, response incomplete";
	}

}
