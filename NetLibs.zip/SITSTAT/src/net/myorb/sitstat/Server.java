
package net.myorb.sitstat;

import net.myorb.netcom.ServerConventions;

import java.util.HashMap;
import java.util.Map;

/**
 * run the SitStat server to monitor the status of services
 * @author Michael Druckman
 */
public class Server
{

	public enum Operations {POST, KILL, FIND}

	public static void main (String[] args) throws Exception
	{
		ServerConventions.provideService (8000, new SitStatService (), "\f");
	}

}

class SitStatService implements ServerConventions.RawTextProcessor
{

	static class Service
	{
		Service (String name, int port)
		{
			this (name);
			this.port = port;
		}
		Service (String name)
		{
			this.name = name;
		}
		String name;
		int port;
	}
	Map<String,Service> services = new HashMap<String,Service> ();
	Map<Integer,Service> ports = new HashMap<Integer,Service> ();

	void error (String message)
	{
		throw new RuntimeException (message);
	}

	public String process (String request) throws Exception
	{
		String message = "Internal Error";

		try
		{
			Server.Operations op = null;
			String[] tokens = request.split (" ");

			try { op = Server.Operations.valueOf (tokens[0]); }
			catch (Exception e) { error ("Service not recognized"); }

			switch (op)
			{
				case POST: return post (tokens);
				case KILL: return kill (tokens);
				case FIND: return find (tokens);
			}
		}
		catch (Exception e)
		{
			message = e.getMessage ();
		}

		return "ERROR " + message;
	}
	
	public String post (String[] tokens)
	{
		String serviceName = tokens[1];
		if (services.containsKey (serviceName))
		{ error ("Redundant post request"); }
		return post (serviceName, tokens);
	}

	public String post (String serviceName, String[] tokens)
	{
		Service s;
		int port = choose (tokens);
		ports.put (port, s = new Service (serviceName, port));
		services.put (serviceName, s);
		return "POSTED " + port;
	}

	public int choose (String[] tokens)
	{
		if (tokens.length < 2)
		{
			return choose (8080);
		}
		else
		{
			try { return choose (Integer.parseInt (tokens[2])); }
			catch (Exception e) { error ("Invalid port request"); }
			throw new RuntimeException ("Internal error");
		}
	}

	public int choose (int starting)
	{
		int port = starting;
		while (ports.containsKey (port)) { port++; }
		return port;
	}

	public String kill (String[] tokens)
	{
		String serviceName = tokens[1];
		Service s = services.get (serviceName);
		if (s == null) error ("Service not found");
		return kill (s);
	}

	public String kill (Service s)
	{
		ports.remove (s.port); services.remove (s.name);
		return "KILLED " + s.name + " on " + s.port;
	}

	public String find (String[] tokens)
	{
		String serviceName = tokens[1];
		Service s = services.get (serviceName);
		if (s == null) error ("Service not found");
		return "FOUND " + s.port;
	}

}

