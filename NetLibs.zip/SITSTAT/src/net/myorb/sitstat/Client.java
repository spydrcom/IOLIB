
package net.myorb.sitstat;

import net.myorb.data.abstractions.ServerAccess;

public class Client extends ServerAccess
{

	public Client () { this ("LOCALHOST", 8000); }

	public Client (String hostName, int portNumber)
	{
		super (hostName, portNumber);
	}

	public String send
		(
			String text
		)
	{
		return issueRequest (text);
	}

}
