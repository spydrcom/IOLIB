
package net.myorb.sitstat;

public class Find extends Client
{

	public static int servicePortFor (String serviceNamed)
	{
		String response = new Find ().send ("FIND " + serviceNamed);
		if (response.startsWith ("ERROR")) throw new RuntimeException (response);
		return Integer.parseInt (response.split (" ")[1]);
	}

}
