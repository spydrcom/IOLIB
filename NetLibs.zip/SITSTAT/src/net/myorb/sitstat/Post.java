
package net.myorb.sitstat;

public class Post extends Client
{

	public static int serviceCalled (String serviceNamed, int requestingPort)
	{
		String request = "POST " + serviceNamed + " ";
		String response = new Post ().send (request + requestingPort);
		if (response.startsWith ("ERROR")) throw new RuntimeException (response);
		return Integer.parseInt (response.split (" ")[1]);
	}

}
