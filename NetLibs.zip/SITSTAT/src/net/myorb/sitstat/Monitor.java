
package net.myorb.sitstat;

/**
 * run the SitStat application to view the status of services
 * @author Michael Druckman
 */
public class Monitor
{

	public static void main (String[] args) throws Exception
	{
		
	}

}
