/**
 * the driver layer of the Situation Status application
 * @author Michael Druckman
 */
package net.myorb.sitstat;