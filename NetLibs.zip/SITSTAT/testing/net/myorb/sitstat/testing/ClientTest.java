
package net.myorb.sitstat.testing;

import net.myorb.sitstat.Client;

public class ClientTest extends Client
{

	public static void main (String[] args) throws Exception
	{
		new ClientTest ().run ();
	}

	public void test (String source)
	{
		System.out.println ("===");
		System.out.print ("> ");
		System.out.println (source);
		System.out.print ("# ");
		System.out.println (send (source));
	}

	public void run ()
	{
		test ("POST SVC 8088");
		test ("POST NXT 8088");
		test ("POST BAD 8085");
		test ("POST SVC 8088");
		test ("POST EVAL 8080");
		test ("POST CALC 8081");
		test ("KILL BAD");
		test ("FIND NXT");
		test ("FIND EVAL");
		test ("FIND CALC");
		System.out.println ("***");
		System.out.println (send ("\f"));
	}

}
