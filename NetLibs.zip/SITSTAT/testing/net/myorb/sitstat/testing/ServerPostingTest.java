
package net.myorb.sitstat.testing;

import net.myorb.netcom.testing.*;
import net.myorb.sitstat.Client;

public class ServerPostingTest extends Client
{

	public static void main (String[] args) throws Exception
	{
		new ServerPostingTest ().run ();
	}

	public int process (String request)
	{
		String response = send (request);
		String[] words = response.split (" ");

		if (words[0].equals ("POSTED"))
		{ System.out.println (response); return Integer.parseInt (words[1]); }
		else { throw new RuntimeException (response); }
	}

	public void run ()
	{
		int port;

		port = process ("POST RAW 8083");
		TcpServer.postTo (port);

		port = process ("POST XML 8083");
		TcpServerXml.postTo (port);

		port = process ("POST JSON 8088");
		TcpServerJson.postTo (port);
	}

}
